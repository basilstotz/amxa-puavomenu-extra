?package(amxa-puavomenu-extra):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="amxa-puavomenu-extra" command="/usr/bin/amxa-puavomenu-extra"
